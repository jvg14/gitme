from itertools import cycle
import random
import time
import sys
import pygame
from pygame.locals import *

FPS = 30
breidd  = 576
haed = 512

# Myndir og hljóð dictionary
myndir, hljod = {}, {}

try:
    xrange
except NameError:
    xrange = range

class Bord5:
    def Opnunargluggi(self, talam):
        # Sýnir upphafsgluggan fyrir borð 2
        leikmadurIndex = 0
        leikmadurIndexGen = cycle([0, 1, 2, 1])
        # Loopiter breytir leikmadurindex eftir hverja fimmtu ítrun
        loopIter = 0

        leikmadurx = int(breidd * 0.2)
        leikmadury = int((haed - myndir["introbill"][0].get_height()) / 2)

        skilabodx = int((breidd - myndir["skilabod"].get_width()) / 2)
        skilabody = int(haed * 0.12)

        # LeikmadurVals fyrir upp og niður hreyfingar á valmyndinni
        leikmadurVals = {"val": 0, "dir": 1}

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    # Framkvæmi fyrstu hljóð og skila fyrir leikinn
                    return {
                        "leikmadury": leikmadury + leikmadurVals["val"],
                        "leikmadurIndexGen": leikmadurIndexGen,
                    }

            # Lagfæra leikmadury, leikmadurIndex
            if (loopIter + 1) % 5 == 0:
                leikmadurIndex = next(leikmadurIndexGen)
            loopIter = (loopIter + 1) % 30
            self.leikmadurValmynd(leikmadurVals)

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["grunnur"], (0,385))
            skjar.blit(myndir["introbill"][talam],
                        (leikmadurx, leikmadury + leikmadurVals["val"]))
            skjar.blit(myndir["skilabod"], (skilabodx, skilabody))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def leikur(self, hreyfingar, stada, talam):


        # Hraði penings
        SulaVelX = -15
        BilSula = breidd

        hljod["lag"].play(50)

        nysula1 = self.Random_Sula(BilSula)
        nysula2 = self.Random_Sula(BilSula)
        nysula3 = self.Random_Sula(BilSula)

        # Listi fyrir súlur
        Sulur = [
        {"x": breidd + 200, "y": nysula1[0]["y"]},
        ]


        # Stað bíls
        BillX = 20
        BillY = 338
        rothaed=BillY
        rot=0
        rothradi=-20

        # leikmaður
        leikmadurYacc = -2
        leikmadurhradi = 0
        leikmadurytt = 26
        ytt=False
        yttaftur=False
        baetavid=True
        t = pygame.time.Clock()
        timisidan=0

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                    if ytt==False:
                        leikmadurhradi = leikmadurytt
                        ytt=True

            # Ath. eftir árekstri við leikmann
            arekst_prof = self.ath_arekstur(BillX, BillY, Sulur, talam)
            if arekst_prof:
                hljod["lag"].stop()
                self.fade(breidd,haed,Sulur, BillX, BillY, rot, talam)
                return stada

            leikmadurMidPos = BillX + myndir["bill"][talam].get_width() / 2
            for sula in Sulur:
                sulaMidPos = sula["x"] + myndir["peningar"][0].get_width() / 2
                if sulaMidPos <= leikmadurMidPos < sulaMidPos + 4:
                    stada += 10
                    hljod["point"].set_volume(0.2)
                    hljod["point"].play()

            # Færa súlur til vinstri
            for sula in Sulur:
                sula["x"] += SulaVelX

            # Taka fyrstu súlu burt og bæta nýrri við
            if Sulur[0]["x"] < -myndir["peningar"][0].get_width():
                Sulur.pop(0)
                baetavid=True

            if Sulur[0]["x"] < BilSula and baetavid:
                nysula = self.Random_Sula(BilSula)
                Sulur.append(nysula[0])
                baetavid=False

            if ytt:
                BillY -= leikmadurhradi
                leikmadurhradi += leikmadurYacc
                if BillY>=338:
                    leikmadurhradi=0
                    BillY=338
                    ytt=False


            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            self.Syna_stodu(stada)

            for sul in Sulur:
                skjar.blit(myndir["peningar"][0], (sul["x"], sul["y"]))

            skjar.blit(myndir["bill"][talam], (BillX,BillY))
            if rothaed==BillY:
                rot+=rothradi

            dekk = pygame.transform.rotate(myndir["bill"][3], rot)
            skjar.blit(dekk, (BillX+11,BillY+22))
            skjar.blit(dekk, (BillX+86,BillY+22))
            skjar.blit(myndir["bill"][talam], (BillX,BillY))
            skjar.blit(myndir["grunnur"], (0,385))


            pygame.display.update()
            FPSCLOCK.tick(FPS)



    def leikmadurValmynd(self, leikmadurValmynd):
          # Lætur gildið af LeikmadurValmynd flakka á milli -8 og 8
        if abs(leikmadurValmynd["val"]) == 8:
            leikmadurValmynd["dir"] *= -1

        if leikmadurValmynd["dir"] == 1:
             leikmadurValmynd["val"] += 1
        else:
            leikmadurValmynd["val"] -= 1

    def Random_Sula(self, BilSula):
        # Skilar randomly gerðri súlu
        # Hæðar munur á efri og neðri súlu
        sulaX = breidd + BilSula

        return [
            {"x": sulaX, "y": 295},  # efri súla
        ]

    def ath_arekstur(self, Leikmadurx, Leikmadury, Sulur, talam):
        # Skila true ef árekstur verður á milli leikmanns og Kúla
        leikmadurb = myndir["bill"][talam].get_width()
        leikmadurh = myndir["bill"][talam].get_height()

        leikmadurhnit = pygame.Rect(Leikmadurx, Leikmadury, leikmadurb, leikmadurh)

        for sulur in Sulur:
            # Efri og neðri súlu hnit
            Sulurb = myndir["bill"][talam].get_width()
            Sulurh = myndir["bill"][talam].get_height()
            Sulurhnit = pygame.Rect(sulur["x"], sulur["y"], Sulurb, Sulurh)


            # Hvort árekstur verður við pening
            arekstur = self.VardArekstur(leikmadurhnit, Sulurhnit)

            if arekstur:
                return True
        return False

    def VardArekstur(self, hnit1, hnit2):
        #Ath. hvort tveir hlutir klessa á hvorn annan
        x=False
        y=False
        Var=2
        xlag = hnit1.x-((hnit1.width)/2.0)+Var
        xhag = hnit1.x+((hnit1.width)/2.0)-Var
        xmin = hnit2.x-((hnit2.width)/2.0)+Var
        xmax = hnit2.x+((hnit2.width)/2.0)-Var
        ylag = hnit1.y-((hnit1.height)/2.0)+Var
        yhag = hnit1.y+((hnit1.height)/2.0)-Var
        ymin = hnit2.y-((hnit2.height)/2.0)+Var
        ymax = hnit2.y+((hnit2.height)/2.0)-Var
        if xhag <= xmax and xhag >= xmin:
            x=True
        if xlag <= xmax and xhag >= xmin:
            x=True
        if yhag <= ymax and yhag >= ymin:
            y=True
        if ylag <= ymax and yhag >= ymin:
            y=True

        if hnit1.y==338:
            xsula = hnit2.x - hnit2.width
            xbill = hnit1.x - hnit1.width
            if xsula < xbill:
                return True

        if y and x:
            return True
        else:
            return False

    def fade(self, width, height, Sulur, BillX, BillY, rot, talam):
        fade = pygame.Surface((width, height))
        fade.fill((0,0,0))
        for alpha in range(0, 300):
            fade.set_alpha(alpha)
            self.redrawWindow(Sulur, BillX, BillY, rot, talam)
            skjar.blit(fade, (0,0))
            pygame.display.update()
            pygame.time.delay(10)

    def redrawWindow(self, Sulur, BillX, BillY, rot, talam):
        skjar.blit(myndir["bakgrunnur"], (0,0))

        for sul in Sulur:
            skjar.blit(myndir["peningar"][0], (sul["x"], sul["y"]))

        skjar.blit(myndir["bill"][0], (BillX,BillY))

        dekk = pygame.transform.rotate(myndir["bill"][3], rot)
        skjar.blit(dekk, (BillX+11,BillY+22))
        skjar.blit(dekk, (BillX+86,BillY+22))
        skjar.blit(myndir["bill"][talam], (BillX,BillY))
        skjar.blit(myndir["grunnur"], (0,385))

    def Syna_stodu(self, stada):
        # Sýni stöðu í miðjum skjánum
        if stada<0:
            minus=True
            stada=stada*-1
        else:
            minus=False
        stadaDigits = [int(x) for x in list(str(stada))]
        totalWidth = 0 # Heildar breidd af öllum númerum sem verða prentuð

        for digit in stadaDigits:
            totalWidth += myndir["numer"][digit].get_width()

        Xoffset = (breidd - totalWidth) / 2
        Xupph = Xoffset-30

        for digit in stadaDigits:
            skjar.blit(myndir["numer"][digit], (Xoffset, haed * 0.1))
            Xoffset += myndir["numer"][digit].get_width()
        skjar.blit(myndir["auka"][1], (Xoffset, haed * 0.095))

        if minus:
            skjar.blit(myndir["auka"][0], (Xupph, haed * 0.12))

    def keyrsla(self, stada, talam):
        global skjar, FPSCLOCK
        pygame.init()
        FPSCLOCK = pygame.time.Clock()
        skjar = pygame.display.set_mode((breidd, haed))
        pygame.display.set_caption("Borð 5")


        # Myndin fyrir opnunargluggan
        myndir["skilabod"] = pygame.image.load("myndirnarb5/valmynd.png").convert_alpha()

        # Númerin fyrir stöðutöfluna
        myndir["numer"] = (
            pygame.image.load("myndirnarb5/0.png").convert_alpha(),
            pygame.image.load("myndirnarb5/1.png").convert_alpha(),
            pygame.image.load("myndirnarb5/2.png").convert_alpha(),
            pygame.image.load("myndirnarb5/3.png").convert_alpha(),
            pygame.image.load("myndirnarb5/4.png").convert_alpha(),
            pygame.image.load("myndirnarb5/5.png").convert_alpha(),
            pygame.image.load("myndirnarb5/6.png").convert_alpha(),
            pygame.image.load("myndirnarb5/7.png").convert_alpha(),
            pygame.image.load("myndirnarb5/8.png").convert_alpha(),
            pygame.image.load("myndirnarb5/9.png").convert_alpha()
        )

        myndir["auka"] = (
            pygame.image.load("myndirnarb5/minus.png").convert_alpha(),
            pygame.image.load("myndirnarb5/milja.png").convert_alpha()
        )

        #Hljóðið
        if "win" in sys.platform:
            HljodExt = ".wav"
        else:
            HljodExt = ".ogg"

        hljod["point"]  = pygame.mixer.Sound("hljodinb5/point" + HljodExt)
        hljod["lag"]  = pygame.mixer.Sound("hljodinb5/lag" + HljodExt)

        while True:
            # Mynd af bakgrunni
            myndir["bakgrunnur"] = pygame.image.load("myndirnarb5/bakg.png").convert()

            # Mynd af grunni
            myndir["grunnur"] = pygame.image.load("myndirnarb5/grunnur.png").convert()

            # Myndin af Bjögga
            myndir["introbill"] = (
                pygame.image.load("myndirnarb5/introbillgr.png").convert_alpha(),
                pygame.image.load("myndirnarb5/introbillblar.png").convert_alpha(),
                pygame.image.load("myndirnarb5/introbillred.png").convert_alpha(),
            )

            # Myndirnar af peningum
            myndir["peningar"] = (
                pygame.image.load("myndirnarb5/penge.png").convert_alpha(),
            )

            # Myndirnar af bil
            myndir["bill"] = (
                pygame.image.load("myndirnarb5/billgraenn.png").convert_alpha(),
                pygame.image.load("myndirnarb5/billblar.png").convert_alpha(),
                pygame.image.load("myndirnarb5/billred.png").convert_alpha(),
                pygame.image.load("myndirnarb5/dekkid.png").convert_alpha(),
            )


            hreyfingar = self.Opnunargluggi(talam)
            stadan = self.leikur(hreyfingar, stada, talam)
            return stadan
