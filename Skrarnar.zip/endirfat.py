from itertools import cycle
import random
import time
import sys
import pygame
from pygame.locals import *

FPS = 30
breidd  = 576
haed = 512

# Myndir og hljóð dictionary
myndir, hljod = {}, {}


try:
    xrange
except NameError:
    xrange = range

class Endirfat:
    def leikur(self, stada):


        # Hraði sólgleraugna
        fangelsiVelY = 4
        fangelsiX = 0
        fangelsiY = -600
        fangelsiYmax = 0

        # Hraði tára
        TarVelY1 = 0.5
        TarVelY2 = 10
        TarY1 = 280
        TarY2 = 700
        TarX = 263
        TarY = 252

        hljod["sad"].play(5)
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()



            if fangelsiYmax > fangelsiY:
                fangelsiY += fangelsiVelY

            if TarY <= TarY1:
                TarY += TarVelY1
            else:
                if TarY <= TarY2:
                    TarY += TarVelY2
                else:
                    randomtala=random.randint(0, 2)
                    if randomtala==0:
                        TarX=263
                        TarY=252
                    if randomtala==1:
                        TarX=283
                        TarY=252
                    if randomtala==2:
                        TarX=340
                        TarY=262

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["leikmadur"][0], (200, 130))
            skjar.blit(myndir["tar"][0], (TarX, TarY))
            skjar.blit(myndir["fangelsi"][0], (fangelsiX, fangelsiY))
            self.Syna_stodu(stada)
            skjar.blit(myndir["lelegt"][0], (100, 20))
            skjar.blit(myndir["lokastada"][0], (40, 400))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def Syna_stodu(self, stada):
        # Sýni stöðu í miðjum skjánum
        if stada<0:
            minus=True
            stada=stada*-1
        else:
            minus=False
        stadaDigits = [int(x) for x in list(str(stada))]
        totalWidth = 0 # Heildar breidd af öllum númerum sem verða prentuð

        for digit in stadaDigits:
            totalWidth += myndir["numer"][digit].get_width()

        Xoffset = (breidd - totalWidth) / 2 + 130
        Xupph = Xoffset-30
        for digit in stadaDigits:
            skjar.blit(myndir["numer"][digit], (Xoffset, haed * 0.8))
            Xoffset += myndir["numer"][digit].get_width()
        skjar.blit(myndir["auka"][1], (Xoffset, haed * 0.792))

        if minus:
            skjar.blit(myndir["auka"][0], (Xupph, haed * 0.82))

    def keyrsla(self, stada):
        global skjar, FPSCLOCK
        pygame.init()
        FPSCLOCK = pygame.time.Clock()
        skjar = pygame.display.set_mode((breidd, haed))
        pygame.display.set_caption("Fátækur")

        # Númerin fyrir stöðutöfluna
        myndir["numer"] = (
            pygame.image.load("myndirendir/0.png").convert_alpha(),
            pygame.image.load("myndirendir/1.png").convert_alpha(),
            pygame.image.load("myndirendir/2.png").convert_alpha(),
            pygame.image.load("myndirendir/3.png").convert_alpha(),
            pygame.image.load("myndirendir/4.png").convert_alpha(),
            pygame.image.load("myndirendir/5.png").convert_alpha(),
            pygame.image.load("myndirendir/6.png").convert_alpha(),
            pygame.image.load("myndirendir/7.png").convert_alpha(),
            pygame.image.load("myndirendir/8.png").convert_alpha(),
            pygame.image.load("myndirendir/9.png").convert_alpha()
        )
        myndir["auka"] = (
            pygame.image.load("myndirendir/minus.png").convert_alpha(),
            pygame.image.load("myndirendir/milja.png").convert_alpha()
        )

        #Hljóðið
        if "win" in sys.platform:
            HljodExt = ".wav"
        else:
            HljodExt = ".ogg"

        hljod["sad"]  = pygame.mixer.Sound("hljodinendir/sad" + HljodExt)


        while True:
            # Mynd af bakgrunni
            myndir["bakgrunnur"] = pygame.image.load("myndirendir/herbergi.png").convert()

            # Myndin af Bjögga
            myndir["leikmadur"] = (
                pygame.image.load("myndirendir/Bjoggi_mid.png").convert_alpha(),
            )

            myndir["lelegt"] = (
                pygame.image.load("myndirendir/lelegt.png").convert_alpha(),
            )

            myndir["fangelsi"] = (
                pygame.image.load("myndirendir/fangelsi.png").convert_alpha(),
            )

            myndir["tar"] = (
                pygame.image.load("myndirendir/tar.png").convert_alpha(),
            )

            myndir["lokastada"] = (
                pygame.image.load("myndirendir/Lokastada.png").convert_alpha(),
            )

            self.leikur(stada)
