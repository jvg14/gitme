from itertools import cycle
import random
import time
import sys
import pygame
from pygame.locals import *

FPS = 30
breidd  = 576
haed = 512

# Myndir og hljóð dictionary
myndir, hljod = {}, {}


try:
    xrange
except NameError:
    xrange = range

class Bord3:
    def Opnunargluggi(self):
        # Sýnir upphafsgluggan fyrir borð 2
        leikmadurIndex = 0
        leikmadurIndexGen = cycle([0, 1, 2, 1])
        # Loopiter breytir leikmadurindex eftir hverja fimmtu ítrun
        loopIter = 0

        leikmadurx = int(breidd * 0.2)
        leikmadury = int((haed - myndir["leikmadur"][0].get_height()) / 2)

        skilabodx = int((breidd - myndir["skilabod"].get_width()) / 2)
        skilabody = int(haed * 0.12)

        # LeikmadurVals fyrir upp og niður hreyfingar á valmyndinni
        leikmadurVals = {"val": 0, "dir": 1}

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    # Framkvæmi fyrstu hljóð og skila fyrir leikinn
                    return {
                        "leikmadury": leikmadury + leikmadurVals["val"],
                        "leikmadurIndexGen": leikmadurIndexGen,
                    }

            # Lagfæra leikmadury, leikmadurIndex
            if (loopIter + 1) % 5 == 0:
                leikmadurIndex = next(leikmadurIndexGen)
            loopIter = (loopIter + 1) % 30
            self.leikmadurValmynd(leikmadurVals)

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["leikmadur"][0],
                        (leikmadurx, leikmadury + leikmadurVals["val"]))
            skjar.blit(myndir["skilabod"], (skilabodx, skilabody))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def leikur(self, hreyfingar, stada):
        stadan=0
        time_elapsed_since_last_action = 0
        timilidinn=0
        clock = pygame.time.Clock()
        klukka = pygame.time.Clock()

        # Hraði Vonda
        VondirVelY = 4
        VondirVelX = 3

        # Fæ random vondan
        nyrvondur = self.Random_Vondur(VondirVelX, VondirVelY)

        # Listi fyrir peninga
        Vondir = [

        ]
        # Listi fyrir kúlur
        Kulur = [

        ]

        # Hraði kúla
        KuluVel = -15

        Einusinni=True
        Leikmadury=470
        Leikmadurx=288
        LeikmadurVel=9
        Leikmadurxmax=540
        Leikmadurxmin=0
        pressed_right=False
        pressed_left=False
        hljod["lag"].play(5)

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_RIGHT:
                    pressed_right = True
                if event.type == KEYDOWN and event.key == K_LEFT:
                    pressed_left = True
                if event.type == KEYUP and event.key == K_RIGHT:
                    pressed_right = False
                if event.type == KEYUP and event.key == K_LEFT:
                    pressed_left = False
                if event.type == KEYDOWN and event.key == K_SPACE:
                    et = klukka.tick()
                    timilidinn += et
                    if timilidinn>150:
                        nykula = {"z": myndir["kula"][0] ,"x": Leikmadurx, "y": Leikmadury}
                        Kulur.append(nykula)
                        timilidinn=0

            # Ath. eftir árekstri við leikmann
            arekst_prof = self.ath_arekstur(Leikmadurx, Leikmadury, Vondir)
            if arekst_prof:
                self.Enda_leik(Leikmadurx, Leikmadury, Vondir)
                return stada

            # Ath. eftir árekstri við kúlu
            arekst_profid = self.ath_arekstur_kula(Kulur, Vondir)
            if arekst_profid:
                stadan+=1
                stada+=1
                hljod["point"].set_volume(0.2)
                hljod["point"].play()

            # Fær pening til að byrja að koma
            dt = clock.tick()
            time_elapsed_since_last_action += dt
            if Einusinni:
                if time_elapsed_since_last_action > 2000:
                    nyrpeningur = self.Random_Vondur(VondirVelX, VondirVelY)
                    Vondir.append(nyrpeningur[0])
                    time_elapsed_since_last_action = 0
                    Einusinni=False

            # Bætir við nýjum pening
            if Einusinni==False:
                if (time_elapsed_since_last_action > 95*random.uniform(0.5, 10)) and stadan<100:
                    nyrpeningur = self.Random_Vondur(VondirVelX, VondirVelY)
                    Vondir.append(nyrpeningur[0])
                    time_elapsed_since_last_action = 0

            #Þessar tvær if setningar gera leikinn erfiðari eftir líður á
            if (time_elapsed_since_last_action > 75*random.uniform(0.5, 10)) and stadan>=100:
                nyrpeningur = self.Random_Vondur(VondirVelX, VondirVelY)
                Vondir.append(nyrpeningur[0])
                time_elapsed_since_last_action = 0

            if (time_elapsed_since_last_action > 200) and stadan>=200:
                nyrpeningur = self.Random_Vondur(VondirVelX, VondirVelY)
                Vondir.append(nyrpeningur[0])
                time_elapsed_since_last_action = 0

            # Færa leikmann
            if pressed_right:
                Leikmadurx += LeikmadurVel
                if Leikmadurx > Leikmadurxmax:
                    Leikmadurx = Leikmadurxmax

            if pressed_left:
                Leikmadurx -= LeikmadurVel
                if Leikmadurx < Leikmadurxmin:
                    Leikmadurx = Leikmadurxmin

            teljari=0
            for vond in Vondir:
                if vond["y"]>600:
                    Vondir.pop(teljari)
                teljari+=1


            # Færa vondu
            for vond in Vondir:
                vond["x"]+=vond["v"]
                vond["y"]+=vond["u"]

            # Færa kúlur
            for kulu in Kulur:
                kulu["y"]+=KuluVel

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            self.Syna_stodu(stada)
            for nyrvondur in Vondir:
                skjar.blit(myndir["vondir"][nyrvondur["z"]], (nyrvondur["x"], nyrvondur["y"]))

            for kula in Kulur:
                skjar.blit(myndir["kula"][0], (kula["x"], kula["y"]))

            skjar.blit(myndir["leikmadur"][0], (Leikmadurx,Leikmadury))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def leikmadurValmynd(self, leikmadurValmynd): # Sama fall og borð 2 notar
          # Lætur gildið af LeikmadurValmynd flakka á milli -8 og 8
        if abs(leikmadurValmynd["val"]) == 8:
            leikmadurValmynd["dir"] *= -1

        if leikmadurValmynd["dir"] == 1:
             leikmadurValmynd["val"] += 1
        else:
            leikmadurValmynd["val"] -= 1

    def Random_Vondur(self, VondirVelX, VondirVelY):
        # Skilar random pening
        # Staðsetning penings
        Mynd = random.randint(0, 4)
        Stad_x = random.randint(0, breidd)
        Stad_y = -50
        if Stad_x<288:
            Velx= VondirVelX*random.uniform(0, 1)
        else:
            Velx=VondirVelX*random.uniform(0, 1)*-1

        Vely=VondirVelY*random.uniform(0.7, 1.4)

        return [
            {"z": Mynd ,"x": Stad_x, "y": Stad_y, "v": Velx, "u": Vely},
        ]

    def ath_arekstur(self, Leikmadurx, Leikmadury, Vondu):
        # Skila true ef árekstur verður á milli leikmanns og Kúla
        leikmadurb = myndir["leikmadur"][0].get_width()
        leikmadurh = myndir["leikmadur"][0].get_height()

        leikmadurhnit = pygame.Rect(Leikmadurx, Leikmadury, leikmadurb, leikmadurh)

        for vondir in Vondu:
            # Efri og neðri súlu hnit
            Vondirb = myndir["vondir"][vondir["z"]].get_width()
            Vondirh = myndir["vondir"][vondir["z"]].get_height()
            Vondirhnit = pygame.Rect(vondir["x"], vondir["y"], Vondirb, Vondirh)


            # Hvort árekstur verður við pening
            arekstur = self.VardArekstur(leikmadurhnit, Vondirhnit)

            if arekstur:
                return True
        return False

    def Enda_leik(self, Leikmadurx, Leikmadury, vondir):
        # Endar leikinn með sprengju
        x=0
        while x<9:
            skjar.blit(myndir["bakgrunnur"], (0,0))
            for vondu in vondir:
                skjar.blit(myndir["vondir"][vondu["z"]], (vondu["x"], vondu["y"]))

            if x<4:
                skjar.blit(myndir["leikmadur"][0], (Leikmadurx,Leikmadury))
            if x==0:
                skjar.blit(myndir["sprengja"][x], (Leikmadurx-20,Leikmadury-100))
                hljod["lag"].stop()
                hljod["boom"].play()
            else:
                time.sleep(0.09)
                skjar.blit(myndir["sprengja"][x], (Leikmadurx-70,Leikmadury-95))
            x+=1

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def ath_arekstur_kula(self, Kulur, Vondu):
        # Skila true ef árekstur verður á milli Kúla og vonda
        kulurb = myndir["kula"][0].get_width()
        kulurh = myndir["kula"][0].get_height()

        telk=0
        telv=0
        for kula in Kulur:
            kulurhnit = pygame.Rect(kula["x"], kula["y"], kulurb, kulurh)
            for vondir in Vondu:
                # Efri og neðri súlu hnit
                Vondirb = myndir["vondir"][vondir["z"]].get_width()
                Vondirh = myndir["vondir"][vondir["z"]].get_height()

                Vondirhnit = pygame.Rect(vondir["x"], vondir["y"], Vondirb, Vondirh)

                # Hvort árekstur verður við pening
                arekstur = self.VardArekstur(kulurhnit, Vondirhnit)

                if arekstur:
                    Vondu.pop(telv)
                    Kulur.pop(telk)
                    return True
                telv+=1
            telv=0
            telk+=1
        telk=0
        return False

    def VardArekstur(self, hnit1, hnit2):
        #Ath. hvort tveir hlutir klessa á hvorn annan
        x=False
        y=False
        xlag = hnit1.x-(hnit1.width)/2.0
        xhag = hnit1.x+(hnit1.width)/2.0
        xmin = hnit2.x-(hnit2.width)/2.0
        xmax = hnit2.x+(hnit2.width)/2.0
        ylag = hnit1.y-(hnit1.height)/2.0
        yhag = hnit1.y+(hnit1.height)/2.0
        ymin = hnit2.y-(hnit2.height)/2.0
        ymax = hnit2.y+(hnit2.height)/2.0
        if xhag <= xmax and xhag >= xmin:
            x=True
        if xlag <= xmax and xhag >= xmin:
            x=True
        if yhag <= ymax and yhag >= ymin:
            y=True
        if ylag <= ymax and yhag >= ymin:
            y=True

        if y and x:
            return True
        else:
            return False

    def Syna_stodu(self, stada):
        # Sýni stöðu í miðjum skjánum
        if stada<0:
            minus=True
            stada=stada*-1
        else:
            minus=False
        stadaDigits = [int(x) for x in list(str(stada))]
        totalWidth = 0 # Heildar breidd af öllum númerum sem verða prentuð

        for digit in stadaDigits:
            totalWidth += myndir["numer"][digit].get_width()

        Xoffset = (breidd - totalWidth) / 2
        Xupph = Xoffset-30
        for digit in stadaDigits:
            skjar.blit(myndir["numer"][digit], (Xoffset, haed * 0.1))
            Xoffset += myndir["numer"][digit].get_width()
        skjar.blit(myndir["auka"][1], (Xoffset, haed * 0.095))

        if minus:
            skjar.blit(myndir["auka"][0], (Xupph, haed * 0.12))

    def keyrsla(self, stada):
        global skjar, FPSCLOCK
        pygame.init()
        FPSCLOCK = pygame.time.Clock()
        skjar = pygame.display.set_mode((breidd, haed))
        pygame.display.set_caption("Borð 3")


        # Myndin fyrir opnunargluggan
        myndir["skilabod"] = pygame.image.load("myndirnarb3/Valmynd.png").convert_alpha()

        # Myndirnar af sprengjum
        myndir["sprengja"] = (
            pygame.image.load("myndirnarb3/exp1.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp2.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp3.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp4.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp5.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp6.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp7.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp8.png").convert_alpha(),
            pygame.image.load("myndirnarb3/exp9.png").convert_alpha(),
        )

        # Númerin fyrir stöðutöfluna
        myndir["numer"] = (
            pygame.image.load("myndirnarb3/0.png").convert_alpha(),
            pygame.image.load("myndirnarb3/1.png").convert_alpha(),
            pygame.image.load("myndirnarb3/2.png").convert_alpha(),
            pygame.image.load("myndirnarb3/3.png").convert_alpha(),
            pygame.image.load("myndirnarb3/4.png").convert_alpha(),
            pygame.image.load("myndirnarb3/5.png").convert_alpha(),
            pygame.image.load("myndirnarb3/6.png").convert_alpha(),
            pygame.image.load("myndirnarb3/7.png").convert_alpha(),
            pygame.image.load("myndirnarb3/8.png").convert_alpha(),
            pygame.image.load("myndirnarb3/9.png").convert_alpha()
        )
        myndir["auka"] = (
            pygame.image.load("myndirnarb3/minus.png").convert_alpha(),
            pygame.image.load("myndirnarb3/milja.png").convert_alpha()
        )

        #Hljóðið
        if "win" in sys.platform:
            HljodExt = ".wav"
        else:
            HljodExt = ".ogg"

        hljod["point"]  = pygame.mixer.Sound("hljodinb3/point" + HljodExt)
        hljod["boom"]  = pygame.mixer.Sound("hljodinb3/boom" + HljodExt)
        hljod["lag"]  = pygame.mixer.Sound("hljodinb3/lag" + HljodExt)

        while True:
            # Mynd af bakgrunni
            myndir["bakgrunnur"] = pygame.image.load("myndirnarb3/skrifstofa.png").convert()

            # Myndin af Bjögga
            myndir["leikmadur"] = (
                pygame.image.load("myndirnarb3/bjoggi-mynd.png").convert_alpha(),
            )

            myndir["kula"] = (
                pygame.image.load("myndirnarb3/Kula.png").convert_alpha(),
            )

            # Myndirnar af peningum
            myndir["vondir"] = (
                pygame.image.load("myndirnarb3/RobertWess.png").convert_alpha(),
                pygame.image.load("myndirnarb3/RSK.png").convert_alpha(),
                pygame.image.load("myndirnarb3/Becks.png").convert_alpha(),
                pygame.image.load("myndirnarb3/Einkrona.png").convert_alpha(),
                pygame.image.load("myndirnarb3/pund.png").convert_alpha(),
            )

            hreyfingar = self.Opnunargluggi()
            stadan = self.leikur(hreyfingar, stada)
            time.sleep(1)
            return stadan
