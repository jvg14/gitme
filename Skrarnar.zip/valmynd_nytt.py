
import sys
import pygame
import sqlite3
import time
from pygame.locals import *

#Define some parameters
breidd = 576
haed = 512

bakgrunnur = pygame.image.load('myndir_val/btb_valmynd_cartoon.png')
level=0

#bílamyndir
rangerover_mynd = pygame.image.load('myndir_val/graenn.png')
tesla_mynd = pygame.image.load('myndir_val/blar.png')
lambo_mynd = pygame.image.load('myndir_val/red.png')

#skjár
staerd_skjar = [breidd,haed]
skjar = pygame.display.set_mode(staerd_skjar, pygame.DOUBLEBUF)

#litir
BLACK = (0, 0, 0)
GRAY = (211,211,211)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (119, 112, 255)

class Valmynd:
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.litur = 0
    #til að setja upp gluggann fyrir leikinn
    def setup(self):
        global done
        global screen
        global clock
        pygame.init()

        #ákveða breidd og hæð á skjánum
        staerd_skjar = [576, 512]
        screen = pygame.display.set_mode(staerd_skjar)
        pygame.display.set_caption("THOR GAMES")

        #notað til að ákvarða hversu hratt skjárinn uppfærist
        clock = pygame.time.Clock()

    #fyrir tónlist
    def music(self,tune):
        pygame.mixer.music.load(tune)
        pygame.mixer.music.set_endevent(pygame.constants.USEREVENT)
        pygame.mixer.music.play(5)

    #fyrir bakgrunnsmyndir t.d.
    def picture(self,bakgrunnur):
        bakgrunnur = pygame.transform.scale(bakgrunnur,staerd_skjar)
        skjar.blit(bakgrunnur,(0,0))

    #kassi fyrir texta med stadsetningu x,y og staerd b,h
    def text_box(self,color,x,y,b,h):
        skjar.fill(color,rect=[x,y,b,h])

    #main menu fyrir leikinn
    def leikurIntro(self):
        self.picture(bakgrunnur)

        self.takkar("Hefja leik",200,280,150,60,GRAY,GREEN,'StartLevel1')
        self.takkar("Um leikinn",200,360,150,60,GRAY,GREEN,'StartUmleikinn')
        self.takkar("Stöðutafla",200,440,150,60,GRAY,GREEN,'StartHighScores')
    #um leikinn, hverjir eru höfundar o.s.frv.
    def um_leikinn(self):
        self.picture(bakgrunnur)
        e = pygame.Surface((550,343))
        e.set_alpha(180)
        e.fill((119,112,216))
        skjar.blit(e, (10,27))


        self.messageDisplayLevel('THOR GAMES ©',300,50)
        self.messageDisplayLevel('Leikurinn er hannaður af', 300,100)
        self.messageDisplayLevel('ALexander Róbert Magnússon', 300,150)
        self.messageDisplayLevel('Ernir Jónsson', 300,200)
        self.messageDisplayLevel('Helgi Kristjánsson', 300,250)
        self.messageDisplayLevel('Jóhann Vignir Guðmundsson', 300,300)
        self.messageDisplayLevel('Í SAMSTARFI VIÐ HÁSKÓLA ÍSLANDS OG INGÓLF HJÖRLEIFSSON', 287,350)
        self.takkar("Til baka",200,400,150,60,GRAY,RED,'quit')

    def top_10(self):

        self.picture(bakgrunnur)
        conn = sqlite3.connect('high_scores.db')
        c = conn.cursor()

        c.execute("""SELECT Notandi,Score FROM high_scores ORDER BY Score desc LIMIT 10""")

        row = c.fetchall()
        s = pygame.Surface((470,424))
        s.set_alpha(150)
        s.fill((119,112,216))
        skjar.blit(s, (48,11))
        k = 37
        for i in row:
            ord=str(i).split(",")
            lengd1=len(ord[0])
            ord1=ord[0][2:lengd1-1]
            lengd2=len(ord[1])
            ord2=ord[1][1:lengd2-1]
            self.messageDisplayLevel(ord1,280,k)
            self.messageDisplayLevel(ord2,480,k)
            k += 42
        n = 37
        numer = ['1.','2.','3.','4.','5.','6.','7.','8.','9.','10.']
        for j in numer:
            self.messageDisplayLevel(j,70,n)
            n += 42

        self.takkar("Til baka",200,440,150,60,GRAY,RED,'quit')
        pygame.display.update()

        c.close() # Close the connection

     #ferð frá hefja leik að þessum glugga
    def level1Intro(self):
        self.picture(bakgrunnur)
        #self.text_box(BLACK,20,50,540,300)
        e = pygame.Surface((540,300))
        e.set_alpha(180)
        e.fill((119,112,216))
        skjar.blit(e, (20,50))

        self.messageDisplayLevel('Sæll, Björgólfur Thor. Nú hefur þú staðið í allskonar braski síðustu ár',290,80)
        self.messageDisplayLevel('og hefur komið þér í gríðarlega skuld vegna þess. Þú skuldar nú 1200 milljarða', 290,110)
        self.messageDisplayLevel('og hefur dottið út af forbes listanum. Lánadrottnar sækja stöðugt á þig t.a.m.', 290,140)
        self.messageDisplayLevel('Deutsche Bank. Þar að auki stendur þú í þrálátum dómshöldum vegna ágreinings', 290,170)
        self.messageDisplayLevel('þíns og Róbert Wessmann. Þú gefst ekki upp og ert staðráðinn í því að komast', 290,200)
        self.messageDisplayLevel('aftur á Forbes listann. Þú getur fylgst með stöðunni þinni uppi í hægra horninu.', 290,230)
        self.messageDisplayLevel('Eins og þú sérð ertu ekki í góðum málum en þú getur unnið þér inn peninga með', 290,260)
        self.messageDisplayLevel('því að fara í gegnum fimm ólík borð. Áður en við byrjum er nr. 1, 2 og 3 ', 290,290)
        self.messageDisplayLevel('að líta vel út. Veldu núna bíl til að keyra þegar þú vinnur þig upp Forbes listann.', 290,320)


        self.takkar("Grænn bíll",30,400,160,60,GRAY,GREEN,'Range')
        self.takkar("Blár bíll",223,400,130,60,GRAY,GREEN,'Tesla')
        self.takkar("Rauður bíll",380,400,180,60,GRAY,GREEN,'Lambo')


    #Föll fyrir alla möguleika á bílum
    def range_rover(self):
        self.picture(bakgrunnur)
        g = pygame.Surface((360,50))
        g.set_alpha(180)
        g.fill((119,112,216))
        skjar.blit(g, (120,22))
        h = pygame.Surface((533,50))
        h.set_alpha(180)
        h.fill((119,112,216))
        skjar.blit(h, (33,362))

        self.messageDisplayLevel('Þú hefur valið grænan bíl!',300,50)
        skjar.blit(rangerover_mynd,(40,200))
        self.messageDisplayLevel('Nú getum við byrjað, viltu byrja leikinn?',300,390)

        self.takkar("JÁ",150,420,100,60,GRAY,GREEN,'StartBord2')
        self.takkar("NEI",300,420,150,60,GRAY,RED,'quit')

    def tesla(self):
        self.picture(bakgrunnur)
        g = pygame.Surface((345,50))
        g.set_alpha(180)
        g.fill((119,112,216))
        skjar.blit(g, (129,22))
        h = pygame.Surface((533,50))
        h.set_alpha(180)
        h.fill((119,112,216))
        skjar.blit(h, (33,351))

        self.messageDisplayLevel('Þú hefur valið bláan bíl!',300,50)
        skjar.blit(tesla_mynd,(40,200))
        self.messageDisplayLevel('Nú getum við byrjað, viltu byrja leikinn?',300,380)

        self.takkar("JÁ",150,420,100,60,GRAY,GREEN,'StartBord2')
        self.takkar("NEI",300,420,150,60,GRAY,RED,'quit')

    def lambo(self):
        self.picture(bakgrunnur)
        g = pygame.Surface((350,50))
        g.set_alpha(180)
        g.fill((119,112,216))
        skjar.blit(g, (125,22))
        h = pygame.Surface((533,50))
        h.set_alpha(180)
        h.fill((119,112,216))
        skjar.blit(h, (33,351))

        self.messageDisplayLevel('Þú hefur valið rauðan bíl!',300,50)
        skjar.blit(lambo_mynd,(40,200))
        self.messageDisplayLevel('Nú getum við byrjað, viltu byrja leikinn?',300,380)

        self.takkar("JÁ",150,420,100,60,GRAY,GREEN,'StartBord2')
        self.takkar("NEI",300,420,150,60,GRAY,RED,'quit')


    #texti skrifaður á bakgrunn
    def messageDisplayLevel(self,text,x,y):
        global level
        if level ==0:
            introtexti = pygame.font.Font('letur_val/Raleway.ttf', 55)
            litur0= BLACK
        elif level ==1:
            introtexti = pygame.font.Font('letur_val/BebasNeue-Regular.ttf', 20)
            litur0= WHITE
        elif level ==2:
            introtexti = pygame.font.Font('letur_val/BebasNeue-Regular.ttf', 30)
            litur0= WHITE
        elif level == 4 or 5 or 6 or 7:
            introtexti = pygame.font.Font('letur_val/BebasNeue-Regular.ttf', 40)
            litur0= WHITE

        textSurf, textRect = self.textObjectsBlack(text, introtexti,litur0)
        textRect.center = (x,y)
        skjar.blit(textSurf, textRect)
    #hjálparfall fyrir takka
    def textObjectsBlack(self,text, font, litur0):
        textSurface = font.render(text, True, litur0)
        return textSurface, textSurface.get_rect()

    #takkar fyrir valmynd
    def takkar(self,text,x,y,breidd,haed,litur1,litur2,action=None):
        global level
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        #gera kassa gráa ef músin fer yfir kassana
        if x+breidd > mouse[0] > x and y+haed > mouse[1] > y:
            pygame.draw.rect(skjar, litur2,(x,y,breidd,haed))
            if click[0] == 1 and action !=None:
                time.sleep(0.2)
                if action == "StartLevel1":
                    level= 1
                    return
                elif action == "StartUmleikinn":
                    level= 2
                    return
                elif action == "StartHighScores":
                    level= 7
                    return
                elif action == 'StartBord2':
                    level=3
                    return
                elif action == 'Range':
                    level=4
                    self.litur=0
                    return
                elif action == 'Tesla':
                    level=5
                    self.litur=1
                    return
                elif action == 'Lambo':
                    level=6
                    self.litur=2
                    return
                elif action == 'quit':
                    level= 0
        else:
            pygame.draw.rect(skjar, litur1,(x,y,breidd,haed))

        litur0= BLACK
        takkar2 = pygame.font.Font('letur_val/Raleway.ttf', 30)
        textSurf, textRect = self.textObjectsBlack(text, takkar2, litur0)
        textRect.center = ((x+(breidd/2)),(y+(haed/2)))
        skjar.blit(textSurf, textRect)

    #keyrslan
    def keyrsla(self):
        self.setup()
        state_tune=1
        #keyrir þangað til að notandi lokar glugganum
        while True:
            #allar skipanir þegar ýtt er á takka
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
            if level ==0:
                if state_tune !=0:
                    self.music('hljod_val/sound.ogg')
                    state_tune=0
                self.leikurIntro()
            elif level ==1:
                self.level1Intro()
            elif level ==2:
                self.um_leikinn()
            elif level ==3:
                pygame.mixer.music.stop()
                return self.litur
            elif level==4:
                self.range_rover()
            elif level==5:
                self.tesla()
            elif level==6:
                self.lambo()
            elif level==7:
                self.top_10()
            pygame.display.update()

            pygame.display.flip()
            #limit 20 rammar á sekúndu
            clock.tick(80)
