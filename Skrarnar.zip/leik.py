from textbox import TextBox
from valmynd_nytt import Valmynd
from bord1 import Bord1
from bord2 import Bord2
from bord3 import Bord3
from bord4 import Bord4
from bord5 import Bord5
from endirfat import Endirfat
from endirmilli import Endirmilli
from endirrikur import Endirrikur
import sqlite3

stada = -1200

textBox = TextBox()
texti=textBox.keyrsla()
valmynd = Valmynd()
litur = valmynd.keyrsla()
print(litur)
leikur1 = Bord1()
stada = leikur1.keyrsla(stada)
leikur2 = Bord2()
stada = leikur2.keyrsla(stada)
leikur3 = Bord3()
stada = leikur3.keyrsla(stada)
leikur4 = Bord4()
stada = leikur4.keyrsla(stada)
leikur5 = Bord5()
stada = leikur5.keyrsla(stada, litur)

conn = sqlite3.connect('high_scores.db')
c = conn.cursor()

#c.execute("""CREATE TABLE high_scores (Notandi CHAR(50), Score INTEGER)""")
c.execute('INSERT INTO high_scores(Notandi,Score)' 'VALUES(?,?)',(texti,stada))
conn.commit() # Save changes


if stada<0:
    endir1 = Endirfat()
    endir1.keyrsla(stada)

if stada>=0 and stada<500:
    endir2 = Endirmilli()
    endir2.keyrsla(stada)

if stada>=500:
    endir3 = Endirrikur()
    endir3.keyrsla(stada)
