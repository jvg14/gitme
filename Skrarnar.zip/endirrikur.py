from itertools import cycle
import random
import time
import sys
import pygame
from pygame.locals import *

FPS = 30
breidd  = 576
haed = 512

# Myndir og hljóð dictionary
myndir, hljod = {}, {}


try:
    xrange
except NameError:
    xrange = range

class Endirrikur:
    def leikur(self, stada):

        time_elapsed_since_last_action = 0
        clock = pygame.time.Clock()

        # Hraði peninga
        PeningaVelY = 4
        PeningaVelX = 3

        # Hraði sólgleraugna nr.1
        SolgVelY = 4
        SolgX = 243
        SolgY = -10
        SolgYmax = 350

        # Hraði sólgleraugna nr.2,3,4,5,6
        SolgVelY1 = 4
        SolgY1 = -3500
        SolgYmax1 = 0

        # Hraði andlita
        andlitVelY = 4
        andlitY = -1000
        andlitY1 = -2000
        andlitY2 = -1500
        andlitY3 = -2500
        andlitY4 = -3000
        andlitYmax = 0

        # Fæ random staðsetningu á pening
        nyrpeningur1 = self.Random_peningar(PeningaVelX)

        # Listi fyrir peninga
        Peningar = [
            {"z": nyrpeningur1[0]["z"], "x": nyrpeningur1[0]["x"], "y": nyrpeningur1[0]["y"], "v": nyrpeningur1[0]["v"]},
        ]

        hljod["rikur"].play(5)
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()

            dt = clock.tick()
            time_elapsed_since_last_action += dt
            if time_elapsed_since_last_action > 100*random.uniform(0.5, 10):
                nyrpeningur = self.Random_peningar(PeningaVelX)
                Peningar.append(nyrpeningur[0])
                time_elapsed_since_last_action = 0

            for penge in Peningar:
                penge["x"]+=penge["v"]
                penge["y"]+=PeningaVelY

            if SolgYmax > SolgY:
                SolgY += SolgVelY

            if SolgYmax1 > SolgY1:
                SolgY1 += SolgVelY1

            if andlitYmax > andlitY:
                andlitY += andlitVelY
            if andlitYmax > andlitY1:
                andlitY1 += andlitVelY
            if andlitYmax > andlitY2:
                andlitY2 += andlitVelY
            if andlitYmax > andlitY3:
                andlitY3 += andlitVelY
            if andlitYmax > andlitY4:
                andlitY4 += andlitVelY

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["solg"][0], (SolgX, SolgY))
            skjar.blit(myndir["andlit"][0], (58, andlitY+280))
            skjar.blit(myndir["andlit"][1], (40, andlitY1+90))
            skjar.blit(myndir["andlit"][2], (435, andlitY2+305))
            skjar.blit(myndir["andlit"][3], (435, andlitY3+90))
            skjar.blit(myndir["andlit"][4], (235, andlitY4+90))
            gleraugu1 = pygame.transform.rotate(myndir["solg"][0], -11)
            skjar.blit(gleraugu1, (67, SolgY1+320))
            skjar.blit(myndir["solg"][1], (241, SolgY1+148))
            gleraugu2 = pygame.transform.rotate(myndir["solg"][1], 9)
            skjar.blit(gleraugu2, (65, SolgY1+155))
            gleraugu3 = pygame.transform.rotate(myndir["solg"][1], 9)
            skjar.blit(gleraugu3, (420, SolgY1+126))
            gleraugu4 = pygame.transform.rotate(myndir["solg"][0], 5)
            skjar.blit(gleraugu4, (433, SolgY1+350))

            for nyrpeningur1 in Peningar:
                skjar.blit(myndir["peningar"][nyrpeningur1["z"]], (nyrpeningur1["x"], nyrpeningur1["y"]))

            skjar.blit(myndir["velgert"][0], (100, 100))
            self.Syna_stodu(stada)
            skjar.blit(myndir["lokastada"][0], (40, 235))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def Syna_stodu(self, stada):
        # Sýni stöðu í miðjum skjánum
        if stada<0:
            minus=True
            stada=stada*-1
        else:
            minus=False
        stadaDigits = [int(x) for x in list(str(stada))]
        totalWidth = 0 # Heildar breidd af öllum númerum sem verða prentuð

        for digit in stadaDigits:
            totalWidth += myndir["numer"][digit].get_width()

        Xoffset = (breidd - totalWidth) / 2 + 130
        Xupph = Xoffset-30
        for digit in stadaDigits:
            skjar.blit(myndir["numer"][digit], (Xoffset, haed * 0.49))
            Xoffset += myndir["numer"][digit].get_width()
        skjar.blit(myndir["auka"][1], (Xoffset, haed * 0.483))

        if minus:
            skjar.blit(myndir["auka"][0], (Xupph, haed * 0.51))

    def Random_peningar(self, PeningaVelX):
        # Skilar random pening
        # Staðsetning penings
        Mynd = random.randint(0, 5)
        Stad_x = random.randint(0, breidd)
        Stad_y = -50
        if Stad_x<288:
            Velx= PeningaVelX*random.uniform(0, 1)
        else:
            Velx=PeningaVelX*random.uniform(0, 1)*-1

        return [
            {"z": Mynd ,"x": Stad_x, "y": Stad_y, "v": Velx},
        ]

    def keyrsla(self, stada):
        global skjar, FPSCLOCK
        pygame.init()
        FPSCLOCK = pygame.time.Clock()
        skjar = pygame.display.set_mode((breidd, haed))
        pygame.display.set_caption("Ríkur")

        # Númerin fyrir stöðutöfluna
        myndir["numer"] = (
            pygame.image.load("myndirendir/0.png").convert_alpha(),
            pygame.image.load("myndirendir/1.png").convert_alpha(),
            pygame.image.load("myndirendir/2.png").convert_alpha(),
            pygame.image.load("myndirendir/3.png").convert_alpha(),
            pygame.image.load("myndirendir/4.png").convert_alpha(),
            pygame.image.load("myndirendir/5.png").convert_alpha(),
            pygame.image.load("myndirendir/6.png").convert_alpha(),
            pygame.image.load("myndirendir/7.png").convert_alpha(),
            pygame.image.load("myndirendir/8.png").convert_alpha(),
            pygame.image.load("myndirendir/9.png").convert_alpha()
        )
        myndir["auka"] = (
            pygame.image.load("myndirendir/minus.png").convert_alpha(),
            pygame.image.load("myndirendir/milja.png").convert_alpha()
        )

        #Hljóðið
        if "win" in sys.platform:
            HljodExt = ".wav"
        else:
            HljodExt = ".ogg"

        hljod["rikur"]  = pygame.mixer.Sound("hljodinendir/rikur" + HljodExt)

        while True:
            # Mynd af bakgrunni
            myndir["bakgrunnur"] = pygame.image.load("myndirendir/forbes.png").convert()

            # Myndin af Bjögga
            myndir["andlit"] = (
                pygame.image.load("myndirendir/Bjoggi.png").convert_alpha(),
                pygame.image.load("myndirendir/bjoggi1.png").convert_alpha(),
                pygame.image.load("myndirendir/bjoggi2.png").convert_alpha(),
                pygame.image.load("myndirendir/bjoggi3.png").convert_alpha(),
                pygame.image.load("myndirendir/bjoggi4.png").convert_alpha(),
            )

            myndir["velgert"] = (
                pygame.image.load("myndirendir/Velgert.png").convert_alpha(),
            )

            myndir["solg"] = (
                pygame.image.load("myndirendir/solg.png").convert_alpha(),
                pygame.image.load("myndirendir/solg1.png").convert_alpha(),
            )

            # Myndirnar af peningum
            myndir["peningar"] = (
                pygame.image.load("myndirnarb1/500kr.png").convert_alpha(),
                pygame.image.load("myndirnarb1/1000kr.png").convert_alpha(),
                pygame.image.load("myndirnarb1/2000kr.png").convert_alpha(),
                pygame.image.load("myndirnarb1/5000kr.png").convert_alpha(),
                pygame.image.load("myndirnarb1/10000kr.png").convert_alpha(),
                pygame.image.load("myndirnarb1/bjoggi-mynd.png").convert_alpha(),
            )

            myndir["lokastada"] = (
                pygame.image.load("myndirendir/Lokastada3.png").convert_alpha(),
            )


            self.leikur(stada)
