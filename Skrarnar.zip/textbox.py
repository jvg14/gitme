import pygame
import sys

pygame.init()
validChars = "`1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm,./"
shiftChars = '~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:"ZXCVBNM<>?'
mynd={}

mynd["bakgrunnur"] = pygame.image.load('myndir_val/btb_valmynd_cartoon.png')

class TextBox(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.text = ""
        self.font = pygame.font.Font(None, 50)
        self.image = self.font.render("Nafn:", False, [119, 112, 216])
        self.rect = self.image.get_rect()

    def add_chr(self, char, shiftDown):
        if char in validChars and not shiftDown:
            self.text += char
        elif char in validChars and shiftDown:
            self.text += shiftChars[validChars.index(char)]
        self.update()

    def update(self):
        old_rect_pos = self.rect.center
        self.image = self.font.render(self.text, False, [119, 112, 216])
        self.rect = self.image.get_rect()
        self.rect.center = old_rect_pos

    def keyrsla(self):
        screen = pygame.display.set_mode([567, 512])
        shiftDown = False
        self.rect.center = [283, 256]

        while True:
          screen.blit(mynd["bakgrunnur"], (0,0))
          screen.blit(self.image, self.rect)
          pygame.display.flip()
          for e in pygame.event.get():
            if e.type == pygame.QUIT or (e.type == pygame.KEYDOWN and e.key ==pygame.K_ESCAPE):
                pygame.quit()
                sys.exit()
            if e.type == pygame.KEYUP:
                if e.key in [pygame.K_RSHIFT, pygame.K_LSHIFT]:
                    shiftDown = False
            if e.type == pygame.KEYDOWN:
                self.add_chr(pygame.key.name(e.key), shiftDown)
                if e.key == pygame.K_SPACE:
                    self.text += " "
                    self.update()
                if e.key in [pygame.K_RSHIFT, pygame.K_LSHIFT]:
                    shiftDown = True
                if e.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                    self.update()
                if e.key == pygame.K_RETURN:
                    if len(self.text) > 0:
                        return self.text
