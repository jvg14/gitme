from itertools import cycle
import random
import time
import sys
import pygame
from pygame.locals import *

FPS = 30
breidd  = 576
haed = 512

# Myndir og hljóð dictionary
myndir, hljod, hitmask = {}, {}, {}

try:
    xrange
except NameError:
    xrange = range

class Bord4:
    def Opnunargluggi(self):
        # Sýnir upphafsgluggan fyrir borð 2
        leikmadurIndex = 0
        leikmadurIndexGen = cycle([0, 1, 2, 1])
        # Loopiter breytir leikmadurindex eftir hverja fimmtu ítrun
        loopIter = 0

        leikmadurx = int(breidd * 0.2)
        leikmadury = int((haed - myndir["leikmadur"][0].get_height()) / 2)

        skilabodx = int((breidd - myndir["skilabod"].get_width()) / 2)
        skilabody = int(haed * 0.12)

        # LeikmadurVals fyrir upp og niður hreyfingar á valmyndinni
        leikmadurVals = {"val": 0, "dir": 1}
        pygame.mouse.set_visible(False)

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                    # Framkvæmi fyrstu hljóð og skila fyrir leikinn
                    return {
                        "leikmadury": leikmadury + leikmadurVals["val"],
                        "leikmadurIndexGen": leikmadurIndexGen,
                    }

            # Lagfæra leikmadury, leikmadurIndex
            if (loopIter + 1) % 5 == 0:
                leikmadurIndex = next(leikmadurIndexGen)
            loopIter = (loopIter + 1) % 30
            self.leikmadurValmynd(leikmadurVals)

            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["leikmadur"][0],
                        (leikmadurx, leikmadury + leikmadurVals["val"]))
            skjar.blit(myndir["skilabod"], (skilabodx, skilabody))

            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def lysing(self):
        stadx=150
        stady=30
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    return
            skjar.blit(myndir["bakgrunnur"], (0,0))
            skjar.blit(myndir["intro"], (stadx,stady))
            pygame.display.update()
            FPSCLOCK.tick(FPS)

    def leikur(self, hreyfingar, stada):

        hljod["hjarta"].play(1000)
        hljod["anda"].set_volume(0.6)
        hljod["anda"].play(100)

        min_timi = 800
        timi_inni = 1300
        Vely = -2

        t1= pygame.time.Clock()
        timi1 = random.uniform(1.0, 10.0)
        time1 = random.uniform(1.0, 2.0)
        timilid1 = 0
        timilidinn1 = 0
        Eruppi1 = False
        satt1=False
        Upp1 = False
        leikx1 = 0
        leiky1 = 235
        max_y1 = 170
        min_y1 = leiky1

        t2 = pygame.time.Clock()
        timi2 = random.uniform(1.0, 10.0)
        time2 = random.uniform(1.0, 2.0)
        timilid2 = 0
        timilidinn2 = 0
        Eruppi2 = False
        satt2 = False
        Upp2 = False
        leikx2 = 135
        leiky2 = 180
        max_y2 = 115
        min_y2 = leiky2

        t3 = pygame.time.Clock()
        timi3 = random.uniform(1.0, 10.0)
        time3 = random.uniform(1.0, 2.0)
        timilid3 = 0
        timilidinn3 = 0
        Eruppi3 = False
        satt3 = False
        Upp3 = False
        leikx3 = 254
        leiky3 = 245
        max_y3 = 180
        min_y3 = leiky3

        t4 = pygame.time.Clock()
        timi4 = random.uniform(1.0, 10.0)
        time4 = random.uniform(1.0, 2.0)
        timilid4 = 0
        timilidinn4 = 0
        Eruppi4 = False
        satt4 = False
        Upp4 = False
        leikx4 = 366
        leiky4 = 180
        max_y4 = 115
        min_y4 = leiky4

        t5 = pygame.time.Clock()
        timi5 = random.uniform(1.0, 10.0)
        time5 = random.uniform(1.0, 2.0)
        timilid5 = 0
        timilidinn5 = 0
        Eruppi5 = False
        satt5 = False
        Upp5 = False
        leikx5 = 476
        leiky5 = 225
        max_y5 = 160
        min_y5 = leiky5

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONUP:
                    hljod["skot"].play()
                    pos = pygame.mouse.get_pos()
                    if Eruppi1 or Upp1:
                        hljod["point"].set_volume(0.3)
                        skot=self.Hitti_Skot(pos, leikx1, leiky1, leikmenn1)
                        if skot:
                            if leikmenn1==1 or leikmenn1==2 or leikmenn1==4 or leikmenn1==5:
                                hljod["point"].play()
                                stada+=5
                                Eruppi1=False
                                satt1=False
                                leiky1=min_y1
                                Upp1=False
                            else:
                                hljod["hjarta"].stop()
                                hljod["anda"].stop()
                                self.fade(breidd, haed, leikx1, leiky1, leikmenn1)
                                return stada
                    if Eruppi2 or Upp2:
                        skot=self.Hitti_Skot(pos, leikx2, leiky2, leikmenn2)
                        if skot:
                            if leikmenn2==1 or leikmenn2==2 or leikmenn2==4 or leikmenn2==5:
                                hljod["point"].play()
                                stada+=5
                                Eruppi2=False
                                satt2=False
                                leiky2=min_y2
                                Upp2=False
                            else:
                                hljod["hjarta"].stop()
                                hljod["anda"].stop()
                                self.fade(breidd, haed, leikx2, leiky2, leikmenn2)
                                return stada
                    if Eruppi3 or Upp3:
                        skot=self.Hitti_Skot(pos, leikx3, leiky3, leikmenn3)
                        if skot:
                            if leikmenn3==1 or leikmenn3==2 or leikmenn3==4 or leikmenn3==5:
                                hljod["point"].play()
                                stada+=5
                                Eruppi3=False
                                satt3=False
                                leiky3=min_y3
                                Upp3=False
                            else:
                                hljod["hjarta"].stop()
                                hljod["anda"].stop()
                                self.fade(breidd, haed, leikx3, leiky3, leikmenn3)
                                return stada
                    if Eruppi4 or Upp4:
                        skot=self.Hitti_Skot(pos, leikx4, leiky4, leikmenn4)
                        if skot:
                            if leikmenn4==1 or leikmenn4==2 or leikmenn4==4 or leikmenn4==5:
                                hljod["point"].play()
                                stada+=5
                                Eruppi4=False
                                satt4=False
                                leiky4=min_y4
                                Upp4=False
                            else:
                                hljod["hjarta"].stop()
                                hljod["anda"].stop()
                                self.fade(breidd, haed, leikx4, leiky4, leikmenn4)
                                return stada
                    if Eruppi5 or Upp5:
                        skot=self.Hitti_Skot(pos, leikx5, leiky5, leikmenn5)
                        if skot:
                            if leikmenn5==1 or leikmenn5==2 or leikmenn5==4 or leikmenn5==5:
                                hljod["point"].play()
                                stada+=5
                                Eruppi5=False
                                satt5=False
                                leiky5=min_y5
                                Upp5=False
                            else:
                                hljod["hjarta"].stop()
                                hljod["anda"].stop()
                                self.fade(breidd, haed, leikx5, leiky5, leikmenn5)
                                return stada

            if Eruppi1==False and Upp1==False:
                et1 = t1.tick()
                timilidinn1 += et1
            if Eruppi1==False and timilidinn1 > timi1*min_timi:
                time1 = random.uniform(1.0, 2.0)
                Eruppi1 = True
                timi1 = random.uniform(1.0, 10.0)
                timilidinn1 = 0
                leikmenn1 = random.randint(0,5)
            if Eruppi1 and max_y1 < leiky1:
                leiky1 += Vely
                if leiky1 <= max_y1:
                    Upp1=True
                    timilid1=0
            dt1 = t1.tick()
            timilid1 += dt1
            if Upp1 and timilid1>timi_inni*time1:
                satt1=True
            if Upp1 and min_y1 > leiky1 and satt1:
                Eruppi1=False
                leiky1-=Vely
                if min_y1 <= leiky1:
                    if leikmenn1==1 or leikmenn1==2 or leikmenn1==4 or leikmenn1==5:
                        hljod["hjarta"].stop()
                        hljod["anda"].stop()
                        self.fade(breidd, haed, leikx1, leiky1, leikmenn1)
                        return stada
                    else:
                        Upp1=False
                        satt1=False

            if Eruppi2==False and Upp2==False:
                et2 = t2.tick()
                timilidinn2 += et2
            if Eruppi2==False and timilidinn2 > timi2*min_timi:
                time2 = random.uniform(1.0, 2.0)
                Eruppi2 = True
                timi2 = random.uniform(1.0, 10.0)
                timilidinn2 = 0
                leikmenn2 = random.randint(0,5)
            if Eruppi2 and max_y2 < leiky2:
                leiky2 += Vely
                if leiky2 <= max_y2:
                    Upp2=True
                    timilid2=0
            dt2 = t2.tick()
            timilid2 += dt2
            if Upp2 and timilid2>timi_inni*time2:
                satt2=True
            if Upp2 and min_y2 > leiky2 and satt2:
                Eruppi2=False
                leiky2-=Vely
                if min_y2 <= leiky2:
                    if leikmenn2==1 or leikmenn2==2 or leikmenn2==4 or leikmenn2==5:
                        hljod["hjarta"].stop()
                        hljod["anda"].stop()
                        self.fade(breidd, haed, leikx2, leiky2, leikmenn2)
                        return stada
                    else:
                        Upp2=False
                        satt2=False

            if Eruppi3==False and Upp3==False:
                et3 = t3.tick()
                timilidinn3 += et3
            if Eruppi3==False and timilidinn3 > timi3*min_timi:
                time3 = random.uniform(1.0, 2.0)
                Eruppi3 = True
                timi3 = random.uniform(1.0, 10.0)
                timilidinn3 = 0
                leikmenn3 = random.randint(0,5)
            if Eruppi3 and max_y3 < leiky3:
                leiky3 += Vely
                if leiky3 <= max_y3:
                    Upp3=True
                    timilid3=0
            dt3 = t3.tick()
            timilid3 += dt3
            if Upp3 and timilid3>timi_inni*time3:
                satt3=True
            if Upp3 and min_y3 > leiky3 and satt3:
                Eruppi3=False
                leiky3-=Vely
                if min_y3 <= leiky3:
                    if leikmenn3==1 or leikmenn3==2  or leikmenn3==4 or leikmenn3==5:
                        hljod["hjarta"].stop()
                        hljod["anda"].stop()
                        self.fade(breidd, haed, leikx3, leiky3, leikmenn3)
                        return stada
                    else:
                        Upp3=False
                        satt3=False

            if Eruppi4==False and Upp4==False:
                et4 = t4.tick()
                timilidinn4 += et4
            if Eruppi4==False and timilidinn4 > timi4*min_timi:
                time4 = random.uniform(1.0, 2.0)
                Eruppi4 = True
                timi4 = random.uniform(1.0, 10.0)
                timilidinn4 = 0
                leikmenn4 = random.randint(0,5)
            if Eruppi4 and max_y4 < leiky4:
                leiky4 += Vely
                if leiky4 <= max_y4:
                    Upp4=True
                    timilid4=0
            dt4 = t4.tick()
            timilid4 += dt4
            if Upp4 and timilid4>timi_inni*time4:
                satt4=True
            if Upp4 and min_y4 > leiky4 and satt4:
                Eruppi4=False
                leiky4-=Vely
                if min_y4 <= leiky4:
                    if leikmenn4==1 or leikmenn4==2 or leikmenn4==4 or leikmenn4==5:
                        hljod["hjarta"].stop()
                        hljod["anda"].stop()
                        self.fade(breidd, haed, leikx4, leiky4, leikmenn4)
                        return stada
                    else:
                        Upp4=False
                        satt4=False

            if Eruppi5==False and Upp5==False:
                et5 = t5.tick()
                timilidinn5 += et5
            if Eruppi5==False and timilidinn5 > timi5*min_timi:
                time5 = random.uniform(1.0, 2.0)
                Eruppi5 = True
                timi5 = random.uniform(1.0, 10.0)
                timilidinn5 = 0
                leikmenn5 = random.randint(0,5)
            if Eruppi5 and max_y5 < leiky5:
                leiky5 += Vely
                if leiky5 <= max_y5:
                    Upp5=True
                    timilid5=0
            dt5 = t5.tick()
            timilid5 += dt5
            if Upp5 and timilid5>timi_inni*time5:
                satt5=True
            if Upp5 and min_y5 > leiky5 and satt5:
                Eruppi5=False
                leiky5-=Vely
                if min_y5 <= leiky5:
                    if leikmenn5==1 or leikmenn5==2 or leikmenn5==4 or leikmenn5==5:
                        hljod["hjarta"].stop()
                        hljod["anda"].stop()
                        self.fade(breidd, haed, leikx5, leiky5, leikmenn5)
                        return stada
                    else:
                        Upp5=False
                        satt5=False


            # Teikna
            skjar.blit(myndir["bakgrunnur"], (0,0))
            self.Syna_stodu(stada)
            if Eruppi1 or Upp1:
                skjar.blit(myndir["leikmenn"][leikmenn1], (leikx1,leiky1))
            if Eruppi2 or Upp2:
                skjar.blit(myndir["leikmenn"][leikmenn2], (leikx2,leiky2))
            if Eruppi3 or Upp3:
                skjar.blit(myndir["leikmenn"][leikmenn3], (leikx3,leiky3))
            if Eruppi4 or Upp4:
                skjar.blit(myndir["leikmenn"][leikmenn4], (leikx4,leiky4))
            if Eruppi5 or Upp5:
                skjar.blit(myndir["leikmenn"][leikmenn5], (leikx5,leiky5))
            skjar.blit(myndir["grunnur"][0], (0,183))
            skjar.blit(myndir["grunnur"][1], (126,138))
            skjar.blit(myndir["grunnur"][2], (242,191))
            skjar.blit(myndir["grunnur"][3], (360,136))
            skjar.blit(myndir["grunnur"][4], (472,182))
            skjar.blit(myndir["grunnur"][5], (0,242))
            skjar.blit( myndir["mus"], ( pygame.mouse.get_pos() ) )


            pygame.display.update()
            FPSCLOCK.tick(FPS)



    def leikmadurValmynd(self, leikmadurValmynd):
          # Lætur gildið af LeikmadurValmynd flakka á milli -8 og 8
        if abs(leikmadurValmynd["val"]) == 8:
            leikmadurValmynd["dir"] *= -1

        if leikmadurValmynd["dir"] == 1:
             leikmadurValmynd["val"] += 1
        else:
            leikmadurValmynd["val"] -= 1

    def Saekja_Hitmask(self, image):
        # Skilar hitmask
        mask = []
        for x in xrange(image.get_width()):
            mask.append([])
            for y in xrange(image.get_height()):
                mask[x].append(bool(image.get_at((x,y))[3]))
        return mask

    def fade(self, width, height, leikx, leiky, leikmenn):
        hljod["wasted"].play()
        fade = pygame.Surface((width, height))
        fade.fill((0,0,0))
        for alpha in range(0, 300):
            fade.set_alpha(alpha)
            self.redrawWindow(leikx, leiky, leikmenn)
            skjar.blit(fade, (0,0))
            skjar.blit(myndir["wasted"][0], (0,-200))
            pygame.display.update()
            pygame.time.delay(10)

    def redrawWindow(self, leikx, leiky, leikmenn):
        skjar.blit(myndir["bakgrunnur"], (0,0))
        skjar.blit(myndir["leikmenn"][leikmenn], (leikx,leiky))
        skjar.blit(myndir["grunnur"][0], (0,183))
        skjar.blit(myndir["grunnur"][1], (126,138))
        skjar.blit(myndir["grunnur"][2], (242,191))
        skjar.blit(myndir["grunnur"][3], (360,136))
        skjar.blit(myndir["grunnur"][4], (472,182))
        skjar.blit(myndir["grunnur"][5], (0,242))

    def Hitti_Skot(self, pos, leikx, leiky, leiknr):
        haedm = myndir["leikmenn"][leiknr].get_height()
        breiddm = myndir["leikmenn"][leiknr].get_width()
        x=pos[0]-leikx
        y=pos[1]-leiky
        if leikx<=pos[0] and leikx+breiddm>pos[0]:
            if leiky<=pos[1] and leiky+haedm>pos[1]:
                if hitmask["leikmenn"][leiknr][x][y]:
                    return True
        return False

    def Syna_stodu(self, stada):
        # Sýni stöðu í miðjum skjánum
        if stada<0:
            minus=True
            stada=stada*-1
        else:
            minus=False
        stadaDigits = [int(x) for x in list(str(stada))]
        totalWidth = 0 # Heildar breidd af öllum númerum sem verða prentuð

        for digit in stadaDigits:
            totalWidth += myndir["numer"][digit].get_width()

        Xoffset = (breidd - totalWidth) / 2
        Xupph = Xoffset-30

        for digit in stadaDigits:
            skjar.blit(myndir["numer"][digit], (Xoffset, haed * 0.1))
            Xoffset += myndir["numer"][digit].get_width()
        skjar.blit(myndir["auka"][1], (Xoffset, haed * 0.095))

        if minus:
            skjar.blit(myndir["auka"][0], (Xupph, haed * 0.12))

    def keyrsla(self, stada):
        global skjar, FPSCLOCK
        pygame.init()
        FPSCLOCK = pygame.time.Clock()
        skjar = pygame.display.set_mode((breidd, haed))
        pygame.display.set_caption("Borð 4")


        # Myndin fyrir opnunargluggan
        myndir["skilabod"] = pygame.image.load("myndirnarb4/valmynd.png").convert_alpha()

        # Númerin fyrir stöðutöfluna
        myndir["numer"] = (
            pygame.image.load("myndirnarb4/0.png").convert_alpha(),
            pygame.image.load("myndirnarb4/1.png").convert_alpha(),
            pygame.image.load("myndirnarb4/2.png").convert_alpha(),
            pygame.image.load("myndirnarb4/3.png").convert_alpha(),
            pygame.image.load("myndirnarb4/4.png").convert_alpha(),
            pygame.image.load("myndirnarb4/5.png").convert_alpha(),
            pygame.image.load("myndirnarb4/6.png").convert_alpha(),
            pygame.image.load("myndirnarb4/7.png").convert_alpha(),
            pygame.image.load("myndirnarb4/8.png").convert_alpha(),
            pygame.image.load("myndirnarb4/9.png").convert_alpha()
        )

        myndir["auka"] = (
            pygame.image.load("myndirnarb4/minus.png").convert_alpha(),
            pygame.image.load("myndirnarb4/milja.png").convert_alpha()
        )

        # Hljóðið
        if "win" in sys.platform:
            HljodExt = ".wav"
        else:
            HljodExt = ".ogg"

        hljod["point"]  = pygame.mixer.Sound("hljodinb4/point" + HljodExt)
        hljod["wasted"]  = pygame.mixer.Sound("hljodinb4/wasted" + HljodExt)
        hljod["skot"]  = pygame.mixer.Sound("hljodinb4/skot" + HljodExt)
        hljod["hjarta"]  = pygame.mixer.Sound("hljodinb4/hjarta" + HljodExt)
        hljod["anda"]  = pygame.mixer.Sound("hljodinb4/anda" + HljodExt)

        while True:
            # Mynd af bakgrunni
            myndir["bakgrunnur"] = pygame.image.load("myndirnarb4/backg.png").convert()

            myndir["mus"] = pygame.image.load("myndirnarb4/Byssa1.png").convert_alpha()

            myndir["intro"] = pygame.image.load("myndirnarb4/intro.png").convert_alpha()

            # Myndin af Bjögga
            myndir["leikmadur"] = (
                pygame.image.load("myndirnarb4/bjoggi-mynd.png").convert_alpha(),
            )

            myndir["wasted"] = (
                pygame.image.load("myndirnarb4/wasted.png").convert_alpha(),
            )

            myndir["leikmenn"] = (
                pygame.image.load("myndirnarb4/DB.png").convert_alpha(),
                pygame.image.load("myndirnarb4/RW.png").convert_alpha(),
                pygame.image.load("myndirnarb4/KJ.png").convert_alpha(),
                pygame.image.load("myndirnarb4/DO.png").convert_alpha(),
                pygame.image.load("myndirnarb4/DBE.png").convert_alpha(),
                pygame.image.load("myndirnarb4/SJ.png").convert_alpha(),
            )

            # Myndirnar af peningum
            myndir["grunnur"] = (
                pygame.image.load("myndirnarb4/grunnur1.png").convert_alpha(),
                pygame.image.load("myndirnarb4/grunnur2.png").convert_alpha(),
                pygame.image.load("myndirnarb4/grunnur3.png").convert_alpha(),
                pygame.image.load("myndirnarb4/grunnur4.png").convert_alpha(),
                pygame.image.load("myndirnarb4/grunnur5.png").convert_alpha(),
                pygame.image.load("myndirnarb4/grunnur6.png").convert_alpha(),
            )

            hitmask["leikmenn"] = (
                self.Saekja_Hitmask(myndir["leikmenn"][0]),
                self.Saekja_Hitmask(myndir["leikmenn"][1]),
                self.Saekja_Hitmask(myndir["leikmenn"][2]),
                self.Saekja_Hitmask(myndir["leikmenn"][3]),
                self.Saekja_Hitmask(myndir["leikmenn"][4]),
                self.Saekja_Hitmask(myndir["leikmenn"][5]),
            )


            hreyfingar = self.Opnunargluggi()
            self.lysing()
            stadan = self.leikur(hreyfingar, stada)
            return stadan
