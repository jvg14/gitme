import unittest
import pygame
from bord4 import Bord4

class Testbord4(unittest.TestCase):

    def test_Saekja_Hitmask(self):
        leikur4=Bord4
        nidurstada = leikur4.Saekja_Hitmask(self, pygame.image.load("myndirnarb4/DB.png"),)
        self.assertFalse(nidurstada[0][0])


if __name__ == '__main__':
    unittest.main()
