import unittest
import pygame
from bord5 import Bord5

class Testbord5(unittest.TestCase):

    def test_Random_Sula(self):
        leikur5=Bord5
        nidurstada = leikur5.Random_Sula(self, 10)
        self.assertNotEqual(nidurstada[0]["x"], -1)
        self.assertEqual(nidurstada[0]["y"], 295)

    def test_VardArekstur(self):
        leikur5=Bord5
        hnit1=pygame.Rect(50, 50, 50, 50)
        hnit2=pygame.Rect(30, 20, 50, 50)
        hnit3=pygame.Rect(230, 420, 50, 50)
        nidurstada1 = leikur5.VardArekstur(self, hnit1, hnit2)
        nidurstada2 = leikur5.VardArekstur(self, hnit1, hnit3)
        self.assertTrue(nidurstada1)
        self.assertFalse(nidurstada2)

if __name__ == '__main__':
    unittest.main()
