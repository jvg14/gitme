import unittest
import pygame
from bord3 import Bord3

class Testbord3(unittest.TestCase):

    def test_Random_Vondur(self):
        leikur3=Bord3
        nidurstada3 = leikur3.Random_Vondur(self, 4, 3)
        self.assertNotEqual(nidurstada3[0]["z"], -1)
        self.assertNotEqual(nidurstada3[0]["x"], -1)
        self.assertNotEqual(nidurstada3[0]["y"], -1)

    def test_VardArekstur(self):
        leikur3=Bord3
        hnit1=pygame.Rect(50, 50, 50, 50)
        hnit2=pygame.Rect(30, 20, 50, 50)
        hnit3=pygame.Rect(230, 420, 50, 50)
        nidurstada1 = leikur3.VardArekstur(self, hnit1, hnit2)
        nidurstada2 = leikur3.VardArekstur(self, hnit1, hnit3)
        self.assertTrue(nidurstada1)
        self.assertFalse(nidurstada2)


if __name__ == '__main__':
    unittest.main()
