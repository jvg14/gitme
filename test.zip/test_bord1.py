import unittest
import pygame
from bord1 import Bord1

class Testbord1(unittest.TestCase):

    def test_Random_Peningur(self):
        leikur=Bord1
        nidurstada = leikur.Random_Peningur(self)
        self.assertNotEqual(nidurstada[0]["z"], -1)
        self.assertNotEqual(nidurstada[0]["x"], -1)
        self.assertNotEqual(nidurstada[0]["y"], -1)

    def test_VardArekstur(self):
        leikur=Bord1
        hnit1=pygame.Rect(50, 50, 50, 50)
        hnit2=pygame.Rect(30, 20, 50, 50)
        hnit3=pygame.Rect(230, 420, 50, 50)
        nidurstada1 = leikur.VardArekstur(self, hnit1, hnit2)
        nidurstada2 = leikur.VardArekstur(self, hnit1, hnit3)
        self.assertTrue(nidurstada1)
        self.assertFalse(nidurstada2)

if __name__ == '__main__':
    unittest.main()
